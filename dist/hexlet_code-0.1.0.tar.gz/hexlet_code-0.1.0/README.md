### Hexlet tests and linter status:
[![Actions Status](https://github.com/Elenlith/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Elenlith/python-project-50/actions)
<a href="https://codeclimate.com/github/Elenlith/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/e6422c8fd302fe89fa2c/maintainability" /></a>
<a href="https://codeclimate.com/github/Elenlith/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e6422c8fd302fe89fa2c/test_coverage" /></a>
[![Github Actions Status](https://github.com/Elenlith/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/Elenlith/python-project-50/actions)

JSON files contents comparison:
<a href="https://asciinema.org/a/IlFcB3WGTFM1eE7kCS5drGhtg" target="_blank"><img src="https://asciinema.org/a/IlFcB3WGTFM1eE7kCS5drGhtg.svg" /></a>

