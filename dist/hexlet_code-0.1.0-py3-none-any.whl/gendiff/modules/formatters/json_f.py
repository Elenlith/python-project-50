import json


def form_json(diff):
    r = json.dumps(diff)
    return r
